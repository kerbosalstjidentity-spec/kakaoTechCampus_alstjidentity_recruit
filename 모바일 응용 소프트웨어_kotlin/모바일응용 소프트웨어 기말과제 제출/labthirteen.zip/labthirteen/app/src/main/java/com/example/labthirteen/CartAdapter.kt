package com.example.labthirteen

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.labthirteen.databinding.ItemCartBinding

// RecyclerView 어댑터 클래스 정의
// CartAdapter는 장바구니 아이템의 리스트를 RecyclerView에 표시하기 위한 어댑터이다.
class CartAdapter(
    // 제거 버튼 클릭 시 호출될 람다 함수
    private val onRemoveClick: (Product) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    // 장바구니 아이템 리스트를 저장하는 변수
    private var cartItems: List<Product> = listOf()

    // RecyclerView의 ViewHolder 정의
    // 각 ViewHolder는 RecyclerView의 각 아이템에 대한 UI를 담당한다.
    inner class CartViewHolder(private val binding: ItemCartBinding) :
        RecyclerView.ViewHolder(binding.root) {

        // 개별 Product 데이터를 View에 바인딩하는 메서드
        fun bind(product: Product) {
            binding.textViewCartProductName.text = product.name // 상품명 설정
            binding.textViewCartProductPrice.text = "$${product.price}" // 상품 가격 설정
            binding.imageViewCartProduct.setImageResource(product.imageResId) // 상품 이미지 설정
            binding.buttonRemove.setOnClickListener {
                onRemoveClick(product) // 제거 버튼 클릭 시 콜백 호출
            }
        }
    }

    // ViewHolder를 생성하는 메서드
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    // ViewHolder와 데이터를 바인딩하는 메서드
    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        holder.bind(cartItems[position]) // 현재 포지션의 아이템 데이터를 ViewHolder에 바인딩
    }

    // RecyclerView에 표시할 아이템 개수를 반환하는 메서드
    override fun getItemCount(): Int = cartItems.size

    // 외부에서 새로운 리스트를 받아 RecyclerView를 업데이트하는 메서드
    fun submitList(items: List<Product>) {
        cartItems = items // 새로운 아이템 리스트 설정
        notifyDataSetChanged() // RecyclerView 갱신
    }
}
