package com.example.labthirteen

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.labthirteen.databinding.FragmentProductListBinding

class ProductListFragment : Fragment() {
    // TAG: 디버깅 및 로깅을 위한 상수
    private val TAG = "ProductListFragment"

    // View Binding을 위한 변수 (뷰 참조)
    private var _binding: FragmentProductListBinding? = null
    private val binding get() = _binding!!

    // 상품 선택 이벤트를 전달하기 위한 리스너
    private var listener: OnProductSelectedListener? = null

    // 선택 기준 변수
    private var isVegetarian: Boolean = false
    private var isVegan: Boolean = false
    private var isGlutenFree: Boolean = false
    private var isKeto: Boolean = false
    private var selectedMeal: String = ""

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.d(TAG, "onAttach called with context: $context")
        if (context is OnProductSelectedListener) {
            listener = context
        } else {
            throw RuntimeException("$context must implement OnProductSelectedListener")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate called")
        arguments?.let {
            // 전달된 선택 기준 초기화
            isVegetarian = it.getBoolean(ARG_IS_VEGETARIAN)
            isVegan = it.getBoolean(ARG_IS_VEGAN)
            isGlutenFree = it.getBoolean(ARG_IS_GLUTEN_FREE)
            isKeto = it.getBoolean(ARG_IS_KETO)
            selectedMeal = it.getString(ARG_SELECTED_MEAL) ?: ""
            Log.d(TAG, "Received arguments: Vegetarian=$isVegetarian, Vegan=$isVegan, GlutenFree=$isGlutenFree, Keto=$isKeto, Meal=$selectedMeal")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreateView called")
        _binding = FragmentProductListBinding.inflate(inflater, container, false) // 뷰 바인딩 초기화

        // 선택 기준에 따른 필터 태그 정의
        val requiredTags = mutableListOf<String>()
        if (isVegetarian) requiredTags.add("Vegetarian")
        if (isVegan) requiredTags.add("Vegan")
        if (isGlutenFree) requiredTags.add("Gluten-Free")
        if (isKeto) requiredTags.add("Keto")
        if (selectedMeal.isNotBlank()) requiredTags.add(selectedMeal)

        Log.d(TAG, "Required tags for filtering: $requiredTags")

        // 미리 정의된 태그를 가진 상품 목록 초기화
        val products = listOf(
            Product(
                id = 1,
                name = "Pizza",
                description = "Delicious cheese pizza topped with fresh tomatoes and basil. Perfect for any occasion!",
                price = 12.99,
                imageResId = R.drawable.pizza,
                tags = listOf("Vegetarian", "Dinner")
            ),
            Product(
                id = 2,
                name = "Burger",
                description = "A juicy beef burger with crispy lettuce, fresh tomatoes, and special sauce. A classic favorite!",
                price = 8.99,
                imageResId = R.drawable.burger,
                tags = listOf("Non-Vegetarian", "Lunch")
            ),
            Product(
                id = 3,
                name = "Sushi",
                description = "Fresh sushi rolls with premium salmon, tuna, and avocado. A taste of Japan!",
                price = 15.99,
                imageResId = R.drawable.sushi,
                tags = listOf("Gluten-Free", "Dinner")
            ),
            Product(
                id = 4,
                name = "Pasta",
                description = "Creamy Alfredo pasta with tender chicken and fresh parsley. Rich and satisfying!",
                price = 10.99,
                imageResId = R.drawable.pasta,
                tags = listOf("Vegetarian", "Lunch")
            ),
            Product(
                id = 5,
                name = "Ice Cream",
                description = "Velvety vanilla ice cream served with a drizzle of chocolate sauce. A sweet treat!",
                price = 5.49,
                imageResId = R.drawable.ice_cream,
                tags = listOf("Vegetarian", "Lunch")
            )
        )

        Log.d(TAG, "Loaded products: ${products.size} items")

        // 필터 태그에 따른 상품 필터링
        val filteredProducts = if (requiredTags.isEmpty()) {
            products
        } else {
            products.filter { product ->
                requiredTags.all { it in product.tags }
            }
        }

        Log.d(TAG, "Filtered products: ${filteredProducts.size} items")

        // RecyclerView를 필터링된 상품으로 설정
        val adapter = ProductAdapter(filteredProducts) { product ->
            Log.d(TAG, "Product selected: ${product.name}")
            listener?.onProductSelected(product) // 상품 선택 이벤트 전달
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(context) // RecyclerView의 레이아웃 설정
        binding.recyclerView.adapter = adapter // 어댑터 연결

        return binding.root
    }

    override fun onDetach() {
        super.onDetach()
        Log.d(TAG, "onDetach called")
        listener = null // 리스너 해제
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(TAG, "onDestroyView called")
        _binding = null // 메모리 누수를 방지하기 위해 바인딩 해제
    }

    // 상품 선택 이벤트를 위한 인터페이스
    interface OnProductSelectedListener {
        fun onProductSelected(product: Product)
    }

    companion object {
        // 프래그먼트에 전달될 선택 기준의 키 값 정의
        private const val ARG_IS_VEGETARIAN = "isVegetarian"
        private const val ARG_IS_VEGAN = "isVegan"
        private const val ARG_IS_GLUTEN_FREE = "isGlutenFree"
        private const val ARG_IS_KETO = "isKeto"
        private const val ARG_SELECTED_MEAL = "selectedMeal"

        // 프래그먼트 인스턴스 생성 메서드
        @JvmStatic
        fun newInstance(
            isVegetarian: Boolean,
            isVegan: Boolean,
            isGlutenFree: Boolean,
            isKeto: Boolean,
            selectedMeal: String
        ) =
            ProductListFragment().apply {
                arguments = Bundle().apply {
                    putBoolean(ARG_IS_VEGETARIAN, isVegetarian)
                    putBoolean(ARG_IS_VEGAN, isVegan)
                    putBoolean(ARG_IS_GLUTEN_FREE, isGlutenFree)
                    putBoolean(ARG_IS_KETO, isKeto)
                    putString(ARG_SELECTED_MEAL, selectedMeal)
                }
            }
    }
}
