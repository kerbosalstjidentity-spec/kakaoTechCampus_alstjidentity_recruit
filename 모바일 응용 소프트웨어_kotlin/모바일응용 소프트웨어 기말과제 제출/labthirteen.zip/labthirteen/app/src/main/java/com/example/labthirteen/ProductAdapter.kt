package com.example.labthirteen

import android.view.LayoutInflater
import android.view.ViewGroup

import androidx.recyclerview.widget.RecyclerView
import com.example.labthirteen.databinding.ItemProductBinding
import com.google.android.material.chip.Chip

// RecyclerView 어댑터 클래스: 상품 정보를 표시하기 위한 어댑터
class ProductAdapter(
    private val products: List<Product>,
    private val onClick: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    // ViewHolder 클래스 정의
    inner class ProductViewHolder(private val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root) {

        // 상품 데이터를 View에 바인딩하는 메서드
        fun bind(product: Product) {
            binding.textProductName.text = product.name // 상품 이름 설정
            binding.textProductPrice.text = "$${product.price}" // 상품 가격 설정
            binding.imageProduct.setImageResource(product.imageResId) // 상품 이미지 설정

            addTagsToChipGroup(product.tags) // 태그 추가

            binding.root.setOnClickListener {
                onClick(product) // 클릭 이벤트 처리
            }
        }

        // ChipGroup에 태그를 추가하는 메서드
        private fun addTagsToChipGroup(tags: List<String>) {
            binding.chipGroupTags.removeAllViews() // 기존 태그 제거
            for (tag in tags) {
                val chip = Chip(binding.chipGroupTags.context).apply {
                    text = tag // 태그 텍스트 설정
                    isClickable = false
                    isCheckable = false
                    // 스타일 커스터마이징 가능
                }
                binding.chipGroupTags.addView(chip) // ChipGroup에 추가
            }
        }
    }

    // ViewHolder를 생성하는 메서드
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ItemProductBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ProductViewHolder(binding)
    }

    // ViewHolder와 데이터를 바인딩하는 메서드
    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(products[position])
    }

    // RecyclerView에 표시할 아이템의 총 개수를 반환하는 메서드
    override fun getItemCount(): Int = products.size
}


