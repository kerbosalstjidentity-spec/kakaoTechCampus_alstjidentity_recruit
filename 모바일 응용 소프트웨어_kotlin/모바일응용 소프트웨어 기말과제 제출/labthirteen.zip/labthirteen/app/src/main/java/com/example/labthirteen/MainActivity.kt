package com.example.labthirteen

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.labthirteen.databinding.ActivityMainBinding

// 메인 액티비티: 로그인 화면을 관리하는 클래스
class MainActivity : AppCompatActivity() {

    // ViewBinding을 위한 변수
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater) // ViewBinding 초기화
        setContentView(binding.root) // 레이아웃 설정

        // 로그인 버튼 클릭 이벤트 처리
        binding.loginButton.setOnClickListener {
            val email = binding.emailInput.text.toString() // 이메일 입력 값
            val password = binding.passwordInput.text.toString() // 비밀번호 입력 값

            if (email.isEmpty() || password.isEmpty()) {
                // 입력값이 비어있는 경우 메시지 표시
                Toast.makeText(this, "이메일과 비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show()
            } else {
                // 로그인 성공 시 다음 액티비티로 이동
                val intent = Intent(this, TestActivity1::class.java).apply {
                    putExtra("user_email", email) // 이메일 데이터 전달
                }
                startActivity(intent) // TestActivity1 실행
                finish() // 현재 로그인 화면 종료
            }
        }

        // 비밀번호 찾기 링크 클릭 이벤트 처리
        binding.forgotPassword.setOnClickListener {
            // 비밀번호 찾기 기능 준비 중 메시지 표시
            Toast.makeText(this, "비밀번호 찾기 기능이 준비 중입니다.", Toast.LENGTH_SHORT).show()
        }
    }
}
