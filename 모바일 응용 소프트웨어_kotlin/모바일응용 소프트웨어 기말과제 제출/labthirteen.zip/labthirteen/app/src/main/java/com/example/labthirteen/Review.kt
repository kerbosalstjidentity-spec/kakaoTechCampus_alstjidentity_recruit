package com.example.labthirteen

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// @Parcelize: Parcelable 인터페이스를 쉽게 구현할 수 있도록 도와주는 Kotlin의 어노테이션
@Parcelize
data class Review(
    val id: Int, // 리뷰 ID (고유 식별자)
    val itemId: Int, // 해당 리뷰가 연결된 아이템 ID
    val profileImageResId: Int, // 사용자의 프로필 이미지 리소스 ID
    val userName: String, // 작성자 이름
    val message: String, // 리뷰 내용
    val reviewTimestamp: Long, // 리뷰 작성 시간 (유닉스 타임스탬프 형식)
    val rating: Float, // 리뷰 평점 (예: 별점)
    var isLiked: Boolean = false, // 좋아요 여부 (기본값: false)
    var likeCount: Int = 0, // 좋아요 개수
    val comments: MutableList<Comment> = mutableListOf() // 댓글 리스트 (기본값: 빈 리스트)
) : Parcelable // Parcelable 인터페이스 구현
