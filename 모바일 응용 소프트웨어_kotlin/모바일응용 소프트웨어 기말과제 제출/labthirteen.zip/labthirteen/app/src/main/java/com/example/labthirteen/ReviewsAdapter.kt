package com.example.labthirteen

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.labthirteen.databinding.ItemReviewBinding
import org.w3c.dom.Comment

/**
 * 리뷰 목록을 표시하기 위한 RecyclerView 어댑터 클래스.
 * @param reviews 표시할 리뷰 목록.
 * @param commentAddListener 댓글 추가 시 호출될 리스너.
 */
class ReviewsAdapter(
    private val reviews: List<Review>, // 표시할 리뷰 목록
    private val commentAddListener: OnCommentAddListener // 댓글 추가를 처리하는 콜백 리스너
) : RecyclerView.Adapter<ReviewsAdapter.ReviewViewHolder>() {

    /**
     * 개별 리뷰 아이템을 표시하기 위한 ViewHolder 클래스.
     * @param binding 리뷰 아이템 레이아웃의 바인딩 객체.
     */
    inner class ReviewViewHolder(private val binding: ItemReviewBinding) :
        RecyclerView.ViewHolder(binding.root) {

        /**
         * Review 객체의 데이터를 아이템 레이아웃의 UI 구성 요소에 바인딩한다.
         * @param review 표시할 Review 객체.
         */
        fun bind(review: Review) {
            // 사용자 이름 설정
            binding.textUserName.text = review.userName
            // 리뷰 메시지 설정
            binding.textReviewMessage.text = review.message
            // 별점 설정
            binding.ratingBar.rating = review.rating
            // 좋아요 개수 설정
            binding.textLikeCount.text = "${review.likeCount}"

            // 프로필 이미지 설정
            binding.imageProfile.setImageResource(review.profileImageResId)

            // 좋아요 버튼 처리
            binding.buttonLike.setImageResource(
                if (review.isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
            binding.buttonLike.setOnClickListener {
                review.isLiked = !review.isLiked // 좋아요 상태 토글
                if (review.isLiked) {
                    review.likeCount += 1 // 좋아요 수 증가
                } else {
                    review.likeCount -= 1 // 좋아요 수 감소
                }
                // 버튼 이미지 및 좋아요 개수 텍스트 업데이트
                binding.buttonLike.setImageResource(
                    if (review.isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
                )
                binding.textLikeCount.text = "${review.likeCount}"
            }

            // 댓글 버튼 처리
            binding.buttonComment.setOnClickListener {
                // 댓글 추가 로직 구현 (예: 다이얼로그 표시)
                // 간단히 샘플 댓글 추가
                val newComment = Comment(
                    id = review.comments.size + 1, // 새로운 댓글 ID
                    reviewId = review.id, // 연결된 리뷰 ID
                    userName = "NewUser", // 새 댓글 사용자 이름
                    message = "새 댓글입니다.", // 새 댓글 메시지
                    commentTimestamp = System.currentTimeMillis() // 댓글 생성 시간
                )
                commentAddListener.onCommentAdd(newComment) // 댓글 추가 콜백 호출
            }

            // 기존 댓글이 있는 경우 바인딩 처리 (필요 시 중첩 RecyclerView 구현 가능)
        }
    }

    /**
     * ViewHolder를 생성하는 메서드.
     * @param parent 부모 ViewGroup.
     * @param viewType 뷰 타입.
     * @return 생성된 ReviewViewHolder.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReviewViewHolder {
        val binding =
            ItemReviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ReviewViewHolder(binding)
    }

    /**
     * ViewHolder에 데이터를 바인딩하는 메서드.
     * @param holder ViewHolder 객체.
     * @param position 데이터 위치.
     */
    override fun onBindViewHolder(holder: ReviewViewHolder, position: Int) {
        holder.bind(reviews[position]) // 해당 위치의 리뷰 데이터 바인딩
    }

    /**
     * 아이템 수를 반환하는 메서드.
     * @return 리뷰 목록의 크기.
     */
    override fun getItemCount(): Int = reviews.size
}
