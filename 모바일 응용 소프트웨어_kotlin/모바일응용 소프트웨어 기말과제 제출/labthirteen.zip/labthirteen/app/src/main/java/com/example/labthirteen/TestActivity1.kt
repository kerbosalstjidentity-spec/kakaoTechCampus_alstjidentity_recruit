package com.example.labthirteen

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.example.labthirteen.databinding.ActivityTest1Binding
import com.google.android.material.navigation.NavigationView

/**
 * TestActivity1는 Navigation Drawer와 체크박스, 라디오 버튼을 사용하여
 * 다양한 입력값을 처리하고 결과를 다음 Activity에 전달하는 역할을 한다.
 */
class TestActivity1 : AppCompatActivity() {
    // View Binding 객체 선언
    private lateinit var binding: ActivityTest1Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // View Binding 초기화
        binding = ActivityTest1Binding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d("TestActivity1", "onCreate 실행됨")

        // Toolbar 설정
        setSupportActionBar(binding.toolbar)
        Log.d("TestActivity1", "Toolbar 설정 완료")

        // Toolbar의 네비게이션 아이콘 설정 (햄버거 아이콘)
        binding.toolbar.setNavigationIcon(R.drawable.ic_menu)
        binding.toolbar.setNavigationOnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.END)
        }

        // DrawerLayout 및 NavigationView 설정
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navigationView: NavigationView = binding.navigationView

        // NavigationView의 헤더 뷰 초기화
        val headerView = navigationView.getHeaderView(0)
        val profileImage = headerView.findViewById<ImageView>(R.id.profile_image)
        val profileName = headerView.findViewById<TextView>(R.id.profile_name)
        val profileEmail = headerView.findViewById<TextView>(R.id.profile_email)

        // MainActivity에서 전달된 사용자 이메일 처리
        val userEmail = intent.getStringExtra("user_email") ?: "user@example.com"
        profileEmail.text = userEmail

        // 프로필 이름 설정
        val userName = userEmail.substringBefore("@")
        profileName.text = userName

        // 기본 프로필 이미지 설정
        profileImage.setImageResource(R.drawable.ic_profile_placeholder)

        // NavigationView 메뉴 클릭 리스너 설정
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    Toast.makeText(this, "홈 선택됨", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_profile -> {
                    Toast.makeText(this, "프로필 선택됨", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_settings -> {
                    Toast.makeText(this, "설정 선택됨", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_about -> {
                    Toast.makeText(this, "소개 선택됨", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_logout -> {
                    Toast.makeText(this, "로그아웃 선택됨", Toast.LENGTH_SHORT).show()
                }
                else -> return@setNavigationItemSelectedListener false
            }
            drawerLayout.closeDrawer(GravityCompat.END)
            true
        }

        // 체크박스 상태 변경 리스너 설정
        binding.checkboxVegetarian.setOnCheckedChangeListener { _, isChecked ->
            Log.d("TestActivity1", "Vegetarian 체크박스 상태 변경: $isChecked")
        }

        binding.checkboxVegan.setOnCheckedChangeListener { _, isChecked ->
            Log.d("TestActivity1", "Vegan 체크박스 상태 변경: $isChecked")
        }

        binding.checkboxGlutenFree.setOnCheckedChangeListener { _, isChecked ->
            Log.d("TestActivity1", "GlutenFree 체크박스 상태 변경: $isChecked")
        }

        binding.checkboxKeto.setOnCheckedChangeListener { _, isChecked ->
            Log.d("TestActivity1", "Keto 체크박스 상태 변경: $isChecked")
        }

        // 라디오 버튼 선택 리스너 설정
        binding.radioGroupMeal.setOnCheckedChangeListener { _, checkedId ->
            val selectedMeal = when (checkedId) {
                binding.radioBreakfast.id -> "Breakfast"
                binding.radioLunch.id -> "Lunch"
                binding.radioDinner.id -> "Dinner"
                else -> "선택 안 됨"
            }
            Log.d("TestActivity1", "선택된 식사: $selectedMeal")
        }

        // 선택 완료 버튼 클릭 리스너
        binding.completeSelection.setOnClickListener {
            Log.d("TestActivity1", "선택 완료 버튼 클릭됨")
            showConfirmationDialog()
        }
    }

    /**
     * 선택 확인 다이얼로그 표시
     */
    private fun showConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Confirm Your Choices")
        builder.setMessage("이대로 선택을 완료하시겠습니까?")

        builder.setPositiveButton("확인") { _, _ ->
            val isVegetarian = binding.checkboxVegetarian.isChecked
            val isVegan = binding.checkboxVegan.isChecked
            val isGlutenFree = binding.checkboxGlutenFree.isChecked
            val isKeto = binding.checkboxKeto.isChecked
            val selectedMeal = when (binding.radioGroupMeal.checkedRadioButtonId) {
                binding.radioBreakfast.id -> "Breakfast"
                binding.radioLunch.id -> "Lunch"
                binding.radioDinner.id -> "Dinner"
                else -> "선택 안 됨"
            }

            val intent = Intent(this, TestActivity2::class.java).apply {
                putExtra("isVegetarian", isVegetarian)
                putExtra("isVegan", isVegan)
                putExtra("isGlutenFree", isGlutenFree)
                putExtra("isKeto", isKeto)
                putExtra("selectedMeal", selectedMeal)
            }
            startActivity(intent)
            Toast.makeText(this, "선택 완료", Toast.LENGTH_SHORT).show()
        }

        builder.setNegativeButton("취소") { dialog, _ ->
            dialog.dismiss()
        }

        builder.create().show()
    }

    /**
     * 백 버튼 동작 처리
     * Drawer가 열려 있으면 닫고, 그렇지 않으면 기본 동작 수행
     */
    override fun onBackPressed() {
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
            binding.drawerLayout.closeDrawer(GravityCompat.END)
        } else {
            super.onBackPressed()
        }
    }
}
