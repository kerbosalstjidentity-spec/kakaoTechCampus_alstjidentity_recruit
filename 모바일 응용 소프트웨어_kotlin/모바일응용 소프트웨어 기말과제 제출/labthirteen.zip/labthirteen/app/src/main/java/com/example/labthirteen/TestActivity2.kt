package com.example.labthirteen

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.labthirteen.databinding.ActivityTest2Binding

/**
 * TestActivity2는 사용자의 선호 데이터를 수신하고 이를 기반으로
 * RecyclerView와 Fragment를 설정하여 제품 목록 및 세부 정보 등을 표시한다.
 */
class TestActivity2 : AppCompatActivity(), ProductListFragment.OnProductSelectedListener {

    private lateinit var binding: ActivityTest2Binding // View Binding 객체 선언

    private val cartViewModel: CartViewModel by viewModels() // ViewModel 초기화

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityTest2Binding.inflate(layoutInflater) // View Binding 초기화
        setContentView(binding.root)

        Log.d("TestActivity2", "onCreate 실행됨")

        // Intent에서 사용자 선호 데이터 수신
        val isVegetarian = intent.getBooleanExtra("isVegetarian", false)
        val isVegan = intent.getBooleanExtra("isVegan", false)
        val isGlutenFree = intent.getBooleanExtra("isGlutenFree", false)
        val isKeto = intent.getBooleanExtra("isKeto", false)
        val selectedMeal = intent.getStringExtra("selectedMeal") ?: "선택 안 됨"

        Log.d(
            "TestActivity2",
            "수신된 데이터: Vegetarian=$isVegetarian, Vegan=$isVegan, GlutenFree=$isGlutenFree, Keto=$isKeto, Meal=$selectedMeal"
        )

        // 사용자 선호사항 데이터를 기반으로 PreferenceItem 리스트 생성
        val preferences = listOf(
            PreferenceItem("채식주의자", isVegetarian),
            PreferenceItem("비건", isVegan),
            PreferenceItem("글루텐 프리", isGlutenFree),
            PreferenceItem("키토", isKeto)
        )
        Log.d("TestActivity2", "Preferences 리스트 생성 완료: $preferences")

        // RecyclerView 설정
        binding.recyclerViewPreferences.apply {
            layoutManager = LinearLayoutManager(this@TestActivity2, LinearLayoutManager.HORIZONTAL, false) // 가로 스크롤 레이아웃 설정
            adapter = PreferenceAdapter(preferences) // 어댑터 설정
        }

        // TextView에 선택된 식사 정보 표시
        binding.textViewMealSelection.text = getString(R.string.selected_meal, selectedMeal)
        Log.d("TestActivity2", "RecyclerView 및 TextView 업데이트 완료")

        // 초기 ProductListFragment 설정
        val productListFragment = ProductListFragment.newInstance(
            isVegetarian = isVegetarian,
            isVegan = isVegan,
            isGlutenFree = isGlutenFree,
            isKeto = isKeto,
            selectedMeal = selectedMeal
        )

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, productListFragment) // 프래그먼트 컨테이너에 추가
            .commit()
        Log.d("TestActivity2", "초기 Fragment 설정 완료")

        // 장바구니 보기 버튼 클릭 리스너 설정
        binding.buttonViewCart.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, CartFragment()) // CartFragment로 전환
                .addToBackStack(null) // 백 스택에 추가
                .commit()
        }
    }

    /**
     * 제품이 선택되었을 때 호출되는 메서드
     * @param product 선택된 Product 객체
     */
    override fun onProductSelected(product: Product) {
        Log.d("TestActivity2", "Product 선택됨: ${product.name}")

        // 선택된 제품의 상세 정보를 표시하는 프래그먼트로 전환
        val detailFragment = ProductDetailFragment.newInstance(product)

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, detailFragment) // 프래그먼트 교체
            .addToBackStack(null) // 백 스택에 추가
            .commit()
        Log.d("TestActivity2", "ProductDetailFragment로 전환 완료")
    }
}
