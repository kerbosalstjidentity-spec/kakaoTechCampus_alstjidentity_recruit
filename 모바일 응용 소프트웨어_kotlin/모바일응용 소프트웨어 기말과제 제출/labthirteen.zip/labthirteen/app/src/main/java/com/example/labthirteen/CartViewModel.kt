package com.example.labthirteen

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

// 장바구니 데이터를 관리하는 ViewModel 클래스
class CartViewModel : ViewModel() {

    // 장바구니에 담긴 제품 리스트를 저장하는 LiveData
    private val _cartItems = MutableLiveData<MutableList<Product>>().apply { value = mutableListOf() }
    val cartItems: LiveData<MutableList<Product>> get() = _cartItems // 외부에 노출되는 LiveData

    // 장바구니에 제품을 추가하는 함수
    fun addToCart(product: Product) {
        _cartItems.value?.let {
            it.add(product) // 제품 추가
            _cartItems.value = it // LiveData 업데이트
        }
    }

    // 장바구니에서 제품을 제거하는 함수
    fun removeFromCart(product: Product) {
        _cartItems.value?.let {
            it.remove(product) // 제품 제거
            _cartItems.value = it // LiveData 업데이트
        }
    }

    // 장바구니 비우기 함수
    fun clearCart() {
        _cartItems.value?.clear() // 리스트 초기화
        _cartItems.value = _cartItems.value // LiveData 업데이트
    }

    // 장바구니에 담긴 제품들의 총액을 계산하는 함수
    fun getTotalPrice(): Double {
        return _cartItems.value?.sumOf { it.price } ?: 0.0 // 제품 가격의 합 반환
    }
}
