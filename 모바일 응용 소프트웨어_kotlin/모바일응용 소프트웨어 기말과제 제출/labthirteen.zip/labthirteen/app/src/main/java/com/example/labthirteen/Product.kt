package com.example.labthirteen

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// 상품 정보를 나타내는 Parcelable 데이터 클래스
@Parcelize
data class Product(
    val id: Int, // 상품 ID
    val name: String, // 상품 이름
    val description: String, // 상품 설명
    val price: Double, // 상품 가격
    val imageResId: Int, // 이미지 리소스 ID
    val tags: List<String> = emptyList(), // 태그 리스트 (기본값: 빈 리스트)
    var isLiked: Boolean = false // 좋아요 여부 (기본값: false)
) : Parcelable
