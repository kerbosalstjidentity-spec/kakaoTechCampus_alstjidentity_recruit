package com.example.labthirteen
// 사용자 선호도를 나타내는 데이터 클래스
data class PreferenceItem(
    val name: String, // 선호도 이름
    val isSelected: Boolean // 선택 여부
)
