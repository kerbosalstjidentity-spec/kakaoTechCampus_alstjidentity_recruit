package com.example.labthirteen

interface OnCommentAddListener {
    // 댓글 추가 시 호출되는 메서드
    fun onCommentAdd(comment: Comment) // 추가된 댓글 데이터를 전달
}
