package com.example.labthirteen


import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// 댓글 데이터를 저장하는 Parcelable 데이터 클래스
@Parcelize
data class Comment(
    val id: Int, // 댓글 ID
    val reviewId: Int, // 리뷰 ID (댓글이 속한 리뷰를 참조)
    val userName: String, // 작성자 이름
    val message: String, // 댓글 내용
    val commentTimestamp: Long // 댓글 작성 시간 (타임스탬프)
) : Parcelable