package com.example.labthirteen

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.example.labthirteen.databinding.FragmentPaymentBinding

// 결제 화면을 구현하는 Fragment 클래스
class PaymentFragment : Fragment() {

    // ViewBinding을 위한 변수 (메모리 관리 차원에서 nullable로 설정)
    private var _binding: FragmentPaymentBinding? = null
    private val binding get() = _binding!! // null이 아님을 보장

    // ViewModel 공유 (Activity와 데이터 공유를 위해 activityViewModels 사용)
    private val cartViewModel: CartViewModel by activityViewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // ViewBinding 초기화
        _binding = FragmentPaymentBinding.inflate(inflater, container, false)

        // 총 결제 금액을 ViewModel에서 가져와서 UI에 표시
        val totalPrice = cartViewModel.getTotalPrice()
        binding.textViewPaymentTotal.text = "총 결제 금액: $$totalPrice"

        // 결제 버튼 클릭 이벤트 처리
        binding.buttonConfirmPayment.setOnClickListener {
            // 실제 결제 로직 구현 위치
            // 예: 결제 API 호출

            // 결제 성공 시
            Toast.makeText(context, "결제가 완료되었습니다!", Toast.LENGTH_SHORT).show()
            cartViewModel.clearCart() // 장바구니 비우기

            // 초기 화면으로 돌아가기
            parentFragmentManager.popBackStack(null, androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE)
        }

        return binding.root // Fragment의 루트 뷰 반환
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // ViewBinding 해제
    }

    companion object {
        // PaymentFragment의 인스턴스를 생성하는 팩토리 메서드
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            PaymentFragment().apply {
                arguments = Bundle().apply {
                    putString(Companion.ARG_PARAM1, param1)
                    putString(Companion.ARG_PARAM2, param2)
                }
            }

        private const val ARG_PARAM1 = "param1"
        private const val ARG_PARAM2 = "param2"
    }
}
