package com.example.labthirteen

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.RatingBar
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.labthirteen.databinding.FragmentReviewsBinding

// 상수 정의: 인자로 전달될 제품 키
private const val ARG_PRODUCT = "arg_product"

/**
 * 리뷰를 표시하고 관리하기 위한 프래그먼트 클래스.
 * @property product 전달받은 제품 데이터.
 */
class ReviewsFragment : Fragment(), OnCommentAddListener {

    private val TAG = "ReviewsFragment" // 디버깅 로그 태그
    private var product: Product? = null // 제품 데이터 저장 변수

    private var _binding: FragmentReviewsBinding? = null // 바인딩 객체 (메모리 누수 방지를 위해 nullable)
    private val binding get() = _binding!! // null 검사 없이 바인딩 객체 접근

    private lateinit var reviewsAdapter: ReviewsAdapter // RecyclerView 어댑터
    private val reviewsList = mutableListOf<Review>() // 리뷰 리스트 데이터 저장소

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            // 전달받은 제품 데이터 초기화
            product = it.getParcelable(ARG_PRODUCT)
            Log.d(TAG, "Received product for reviews: ${product?.name}")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        Log.d(TAG, "onCreateView called in ReviewsFragment")
        _binding = FragmentReviewsBinding.inflate(inflater, container, false) // 바인딩 초기화

        // RecyclerView 초기화
        reviewsAdapter = ReviewsAdapter(reviewsList, this)
        binding.recyclerViewReviews.apply {
            layoutManager = LinearLayoutManager(context) // 세로 레이아웃 매니저 설정
            adapter = reviewsAdapter // 어댑터 설정
        }

        // 리뷰 데이터 로드
        loadReviews()

        // 리뷰 추가 버튼 클릭 리스너 설정
        binding.buttonAddReview.setOnClickListener {
            showAddReviewDialog() // 리뷰 추가 다이얼로그 표시
        }

        return binding.root // 레이아웃 반환
    }

    /**
     * 리뷰 데이터를 로드하는 메서드.
     * 실제 데이터 로직 대신 샘플 데이터 추가.
     */
    private fun loadReviews() {
        reviewsList.add(
            Review(
                id = 1,
                itemId = product!!.id,
                profileImageResId = R.drawable.ic_profile,
                userName = "Alice",
                message = "정말 유용한 정보 감사합니다!",
                reviewTimestamp = System.currentTimeMillis(),
                rating = 4.5f,
                isLiked = false,
                likeCount = 10
            )
        )
        reviewsList.add(
            Review(
                id = 2,
                itemId = product!!.id,
                profileImageResId = R.drawable.ic_profile,
                userName = "Bob",
                message = "사용하기 편리해요.",
                reviewTimestamp = System.currentTimeMillis(),
                rating = 4.0f,
                isLiked = true,
                likeCount = 5
            )
        )
        reviewsAdapter.notifyDataSetChanged() // 데이터 변경 알림
        Log.d(TAG, "Loaded ${reviewsList.size} reviews")
    }

    /**
     * 리뷰 추가 다이얼로그를 표시하는 메서드.
     */
    private fun showAddReviewDialog() {
        val inflater = LayoutInflater.from(requireContext())
        val dialogView = inflater.inflate(R.layout.dialog_add_review, null) // 커스텀 레이아웃 인플레이트

        // 다이얼로그 UI 요소 초기화
        val editTextUserName = dialogView.findViewById<EditText>(R.id.editTextUserName)
        val editTextReviewMessage = dialogView.findViewById<EditText>(R.id.editTextReviewMessage)
        val ratingBar = dialogView.findViewById<RatingBar>(R.id.ratingBar)

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("리뷰 추가")
            .setView(dialogView)
            .setPositiveButton("추가") { dialogInterface, _ ->
                // 사용자 입력 값 가져오기
                val userName = editTextUserName.text.toString().trim()
                val reviewMessage = editTextReviewMessage.text.toString().trim()
                val rating = ratingBar.rating

                // 입력값 유효성 검사
                if (userName.isEmpty()) {
                    editTextUserName.error = "사용자 이름을 입력해주세요."
                    return@setPositiveButton
                }
                if (reviewMessage.isEmpty()) {
                    editTextReviewMessage.error = "리뷰 메시지를 입력해주세요."
                    return@setPositiveButton
                }

                // 새로운 리뷰 객체 생성
                val newReview = Review(
                    id = (reviewsList.maxOfOrNull { it.id } ?: 0) + 1,
                    itemId = product!!.id,
                    profileImageResId = R.drawable.ic_profile,
                    userName = userName,
                    message = reviewMessage,
                    reviewTimestamp = System.currentTimeMillis(),
                    rating = rating,
                    isLiked = false,
                    likeCount = 0
                )

                reviewsList.add(newReview) // 리뷰 리스트에 추가
                reviewsAdapter.notifyItemInserted(reviewsList.size - 1) // 어댑터에 변경 알림
                binding.recyclerViewReviews.scrollToPosition(reviewsList.size - 1) // 새 리뷰로 스크롤
                Log.d(TAG, "Added new review: ${newReview.userName}")
                dialogInterface.dismiss() // 다이얼로그 닫기
            }
            .setNegativeButton("취소") { dialogInterface, _ ->
                dialogInterface.dismiss() // 다이얼로그 닫기
            }
            .create()

        dialog.show() // 다이얼로그 표시
    }

    /**
     * 댓글 추가 이벤트를 처리하는 메서드.
     * @param comment 추가된 댓글 객체.
     */
    override fun onCommentAdd(comment: Comment) {
        val review = reviewsList.find { it.id == comment.reviewId } // 댓글이 속한 리뷰 찾기
        review?.let {
            it.comments.add(comment) // 댓글 추가
            reviewsAdapter.notifyDataSetChanged() // 데이터 변경 알림
            Log.d(TAG, "Added comment to review ${it.id}: ${comment.message}")
        } ?: Log.e(TAG, "Review not found for comment") // 리뷰가 없는 경우 로그 출력
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(TAG, "onDestroyView called in ReviewsFragment")
        _binding = null // 바인딩 해제
    }

    companion object {
        /**
         * 새로운 인스턴스를 생성하기 위한 메서드.
         * @param product 전달할 제품 객체.
         * @return 생성된 ReviewsFragment 객체.
         */
        @JvmStatic
        fun newInstance(product: Product) =
            ReviewsFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_PRODUCT, product) // 제품 데이터 전달
                }
            }
    }
}
