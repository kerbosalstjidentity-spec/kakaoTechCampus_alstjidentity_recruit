package com.example.labthirteen

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.labthirteen.databinding.FragmentCartBinding

// 장바구니 화면을 구현하는 Fragment 클래스
class CartFragment : Fragment() {

    // ViewBinding을 위한 변수 (메모리 관리 차원에서 nullable로 설정)
    private var _binding: FragmentCartBinding? = null
    private val binding get() = _binding!! // null이 아님을 보장

    // ViewModel 공유 (Activity와 데이터 공유를 위해 activityViewModels 사용)
    private val cartViewModel: CartViewModel by activityViewModels()

    // RecyclerView 어댑터
    private lateinit var adapter: CartAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // ViewBinding 초기화
        _binding = FragmentCartBinding.inflate(inflater, container, false)

        // CartAdapter 초기화 (아이템 제거 콜백 전달)
        adapter = CartAdapter { product ->
            cartViewModel.removeFromCart(product) // ViewModel을 통해 아이템 제거
        }

        // RecyclerView 설정
        binding.recyclerViewCart.apply {
            layoutManager = LinearLayoutManager(context) // 세로 방향 리스트 레이아웃 설정
            adapter = this@CartFragment.adapter // 어댑터 연결
        }

        // ViewModel의 cartItems LiveData를 관찰하여 UI 업데이트
        cartViewModel.cartItems.observe(viewLifecycleOwner) { cartItems ->
            adapter.submitList(cartItems.toList()) // RecyclerView에 새로운 데이터 전달
            binding.textViewTotalPrice.text = "총액: $${cartViewModel.getTotalPrice()}" // 총액 표시
        }

        // 결제 버튼 클릭 리스너 설정
        binding.buttonCheckout.setOnClickListener {
            // 결제 화면으로 이동
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, PaymentFragment()) // PaymentFragment로 화면 전환
                .addToBackStack(null) // 뒤로가기 스택에 추가
                .commit()
        }

        return binding.root // Fragment의 루트 뷰 반환
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // ViewBinding 해제
    }
}
