package com.example.labthirteen

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.example.labthirteen.databinding.FragmentProductDetailBinding
import com.google.android.material.chip.Chip

private const val ARG_PRODUCT = "arg_product"

class ProductDetailFragment : Fragment() {
    // TAG: 디버깅 및 로깅을 위한 상수
    private val TAG = "ProductDetailFragment"

    // 상품 데이터를 저장할 변수
    private var product: Product? = null

    // View Binding을 위한 변수 (뷰 참조)
    private var _binding: FragmentProductDetailBinding? = null
    private val binding get() = _binding!!

    // ViewModel을 사용하여 데이터 공유
    private val cartViewModel: CartViewModel by activityViewModels()

    // "좋아요" 상태를 저장할 변수
    private var isLiked: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate called")
        arguments?.let {
            product = it.getParcelable(ARG_PRODUCT) // 전달된 상품 데이터 가져오기
            Log.d(TAG, "Received product: ${product?.name}")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        Log.d(TAG, "onCreateView called")
        _binding = FragmentProductDetailBinding.inflate(inflater, container, false) // 뷰 바인딩 초기화

        // 상품 데이터를 UI에 설정
        product?.let { prod ->
            Log.d(TAG, "Displaying product details: ${prod.name}")
            binding.textProductName.text = prod.name
            binding.textProductDescription.text = prod.description
            binding.textProductPrice.text = "$${prod.price}"
            binding.imageProductDetail.setImageResource(prod.imageResId)

            // 상품 태그를 ChipGroup에 추가
            if (prod.tags.isNotEmpty()) {
                Log.d(TAG, "Adding tags to ChipGroup: ${prod.tags}")
                addTagsToChipGroup(prod.tags)
            } else {
                Log.d(TAG, "No tags found for product")
                binding.chipGroupTags.visibility = View.GONE
            }

            // "좋아요" 초기 상태 설정
            isLiked = prod.isLiked
            updateLikeButton()

            // "좋아요" 버튼 클릭 리스너 설정
            binding.buttonLike.setOnClickListener { view ->
                isLiked = !isLiked
                view.isEnabled = false // 버튼 다중 클릭 방지
                binding.buttonLike.postDelayed({
                    view.isEnabled = true
                }, 300)
                updateLikeButton()
                prod.isLiked = isLiked // 상품의 "좋아요" 상태 업데이트
                Log.d(TAG, "Product like state changed: isLiked=$isLiked")
            }

            // 공유 버튼 클릭 리스너 설정
            binding.buttonShare.setOnClickListener {
                shareProduct()
            }

            // 리뷰 보기 버튼 클릭 리스너 설정
            binding.buttonViewReviews.setOnClickListener {
                navigateToReviews(prod)
            }

            // 장바구니 추가 버튼 클릭 리스너 설정
            binding.buttonAddToCart.setOnClickListener {
                cartViewModel.addToCart(product!!) // ViewModel을 통해 장바구니에 추가
                Toast.makeText(context, "${product!!.name} 장바구니에 추가됨", Toast.LENGTH_SHORT).show()
            }
        } ?: Log.e(TAG, "Product data is null")

        return binding.root
    }

    // ChipGroup에 태그를 추가하는 메서드
    private fun addTagsToChipGroup(tags: List<String>) {
        for (tag in tags) {
            val chip = Chip(requireContext()).apply {
                text = tag
                isClickable = false
                isCheckable = false
            }
            Log.d(TAG, "Adding chip for tag: $tag")
            binding.chipGroupTags.addView(chip)
        }
    }

    // "좋아요" 버튼의 UI를 업데이트하는 메서드
    private fun updateLikeButton() {
        binding.buttonLike.setImageResource(
            if (isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        )
    }

    // 상품을 공유하는 메서드
    private fun shareProduct() {
        product?.let { prod ->
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out this product: ${prod.name}\n${prod.description}\nPrice: $${prod.price}"
                )
                type = "text/plain"
            }
            startActivity(Intent.createChooser(shareIntent, "Share Product"))
            Log.d(TAG, "Product shared: ${prod.name}")
        } ?: Log.e(TAG, "Cannot share. Product is null")
    }

    // 리뷰 화면으로 이동하는 메서드
    private fun navigateToReviews(prod: Product) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, ReviewsFragment.newInstance(prod))
            .addToBackStack(null)
            .commit()
        Log.d(TAG, "Navigating to ReviewsFragment")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(TAG, "onDestroyView called")
        _binding = null // 메모리 누수를 방지하기 위해 바인딩 해제
    }

    companion object {
        // 프래그먼트 인스턴스를 생성하는 메서드
        @JvmStatic
        fun newInstance(product: Product) =
            ProductDetailFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_PRODUCT, product)
                    Log.d(TAG, "Product passed to fragment: ${product.name}")
                }
            }
    }
}
