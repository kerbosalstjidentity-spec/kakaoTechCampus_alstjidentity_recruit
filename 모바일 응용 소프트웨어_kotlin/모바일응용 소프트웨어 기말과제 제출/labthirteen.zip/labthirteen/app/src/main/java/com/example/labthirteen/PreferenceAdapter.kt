package com.example.labthirteen

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// RecyclerView 어댑터 클래스: 사용자 선호도를 표시하기 위한 어댑터
class PreferenceAdapter(private val preferences: List<PreferenceItem>) :
    RecyclerView.Adapter<PreferenceAdapter.PreferenceViewHolder>() {

    // ViewHolder를 생성하는 메서드
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PreferenceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_preference, parent, false) // item_preference 레이아웃 inflate
        return PreferenceViewHolder(view) // ViewHolder 반환
    }

    // ViewHolder와 데이터를 바인딩하는 메서드
    override fun onBindViewHolder(holder: PreferenceViewHolder, position: Int) {
        val preference = preferences[position] // 현재 위치의 PreferenceItem 가져오기
        holder.bind(preference) // ViewHolder에 데이터 바인딩
    }

    // RecyclerView에 표시할 아이템의 총 개수를 반환하는 메서드
    override fun getItemCount(): Int = preferences.size

    // RecyclerView의 ViewHolder 클래스 정의
    class PreferenceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewPreference: TextView = itemView.findViewById(R.id.textViewPreference) // TextView 참조

        // PreferenceItem 데이터를 View에 바인딩하는 메서드
        fun bind(preference: PreferenceItem) {
            textViewPreference.text = preference.name // 이름 설정
            textViewPreference.visibility = if (preference.isSelected) View.VISIBLE else View.GONE // 선택 여부에 따라 가시성 설정
        }
    }
}
